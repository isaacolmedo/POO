//Problema del diamante

protocol Aa {
    func aa()
}

extension Aa {
    func aa() {
        print("A")
    }
}

protocol Bb: Aa { }
extension Bb {
    func aa() {
        print("B")
    }
}

protocol Cc: Aa { }
extension Cc {
    func aa() {
        print("C")
    }
}

class Dd: Cc, Bb {
    func aa() {
        print("D")
    }
    
    func preguntarPorAA() {
        aa()
    }
}


let objD = Dd()
objD.preguntarPorAA()

