
protocol Animal {
    var nombre: String { get }
    init(nombre: String)
    func hablar() -> String
}

class Perro: Animal {
    
    let nombre: String
    
    required init(nombre: String) {
        self.nombre = nombre
    }

    func hablar() -> String {
        return "Guauuu!!!"
    }
}

class Gato: Animal {
    
    let nombre: String
    
    required init(nombre: String) {
        self.nombre = nombre
    }

    func hablar() -> String {
        return "Miaaauu!!!"
    }
}



let animales: [Animal] = [Gato(nombre: "Gatosan"), Perro(nombre: "Max"), Gato(nombre: "Bigotes")]

for animal in animales {
    print("\(animal.nombre) dice \(animal.hablar())")
}

//let a = Animal("fantasma")
//a.hablar()
