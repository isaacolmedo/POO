
class Persona4 {
    let nombre: String
    let apellido: String
    let edad: Int
    let estatura: Double
    let dinero: Double
    
    init(nombre: String, apellido: String, edad: Int, estatura: Double, dinero: Double) {
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad
        self.estatura = estatura
        self.dinero = dinero
    }
    
    class func vivir() {
        print("Soy una \(Persona4.self) y estoy vivo!")
    }
    
    static func respirar() {
        print("respirar")
    }
    
    func comer() {
        print("comer")
    }
}


let alan = Persona4(nombre: "alan",apellido: "garrido",edad: 23,estatura: 1.80,dinero: 200)

//Metodo de clase
Persona4.vivir()
//alan.vivir()

//Metodo estatico
Persona4.respirar()
//alan.respirar()

//Metodo
Persona4.comer(alan)
alan.comer()
