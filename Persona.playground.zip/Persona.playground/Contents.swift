import UIKit

var greeting = "Hello, playground"

debugPrint("Primer ejemplo de POO")

class Persona {
    //Atributos
    
    let edad: Int
    let saludo: String
    
    init(edad: Int, saludo: String) {
        self.edad = edad
        self.saludo = saludo
    }
    
    func saludar()  {
        debugPrint("\(saludo) soy una Persona")
    }
    
    func unaFuncion() {
        debugPrint("Eso es una función de clase")
    }
}

//Instancia o creación de un objeto a partir de una clase
let jorge = Persona(edad: 21, saludo: "Hola amigos")

print(jorge.edad)
print(jorge.saludo)

jorge.saludar()

Persona.unaFuncion

//print(Persona.edad)


