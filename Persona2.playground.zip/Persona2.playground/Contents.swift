

class Persona2 {
    init() {
        print("Se ha creado una persona, y se imprimió este mensaje")
    }
    
    func saludar() {
        print("Hola soy una persona")
    }
    
    func comer() {
        print("Estoy comiendo, no me molestes!")
    }
    
    func estudiar() {
        print("Estoy aprendiendo POO")
    }
}


let juan = Persona2()
let edgar = Persona2()
let alan = Persona2()

juan.saludar()
edgar.comer()
alan.estudiar()

